import './hot-categories.scss';
