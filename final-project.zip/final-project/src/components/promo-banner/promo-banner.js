import './promo-banner.scss';
